# jeevanPlusBackend

Data set used for the training and testing of the model is Indian Food Image Dataset.
Source : https://www.kaggle.com/iamsouravbanerjee/indian-food-images-dataset


