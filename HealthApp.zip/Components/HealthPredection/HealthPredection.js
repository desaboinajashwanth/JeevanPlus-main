import React, { Component } from 'react';
import { styles } from './HealthPredection.styles';
import {
  View,
  SafeAreaView,
  ScrollView,
  ImageBackground,
  Image,
} from 'react-native';
import { Card, Text, Button, FAB, Title, Paragraph } from 'react-native-paper';
import Icon from 'react-native-vector-icons/FontAwesome';
import EntypoIcon from 'react-native-vector-icons/Entypo';
import FoodContentStatusComponent from '../FoodContentStatusComponent/FoodContentStatusComponent';
import connectToRedux from '../../_services/_reduxService';
import LoadingComponent from '../LoadingComponent/LoadingComponent';
import axios from 'axios';
import { DeviceConfig, ServerConfig } from '../../Constants';
import RNFS from 'react-native-fs';
import HealthPredictor from '../../_services/_predictionHelperService';
import { capatalizeText } from '../../_services/_utilServices';
import * as Constants from '../../Constants';
import AntDesignIcon from 'react-native-vector-icons/AntDesign';
import MatCommunityIcon from 'react-native-vector-icons/MaterialCommunityIcons';

class HealthPredection extends Component {
  SERVER_RESPONSE_DELAY = 0;

  constructor(props) {
    super(props);

    this.state = {
      windowPercentHeight: Math.floor((55 / 100) * DeviceConfig.WINDOW_HEIGHT),
      capturedImageUri: null,
      hasError: false,
      isLoading: true,
      predictionReport: null,
      foodName: 'Identifying...',
      prediction: 'Predicting...',
    };
  }

  async getBase64(imageUri) {
    const filepath = imageUri.split('//')[1];
    const imageUriBase64 = await RNFS.readFile(filepath, 'base64');
    return `data:image/jpeg;base64,${imageUriBase64}`;
  }

  async componentDidMount() {
    const base64 = await this.getBase64(
      this.props.getSavedData().capturedImageUri,
    );

    this.setState({
      base64ImageForServer: base64,
      capturedImageUri: this.props.getSavedData().capturedImageUri,
    });
  }

  async componentDidUpdate(prevProps, prevState) {
    if (prevState.capturedImageUri !== this.state.capturedImageUri) {
      const base64 = await this.getBase64(
        this.props.getSavedData().capturedImageUri,
      );

      this.setState(
        {
          base64ImageForServer: base64,
          capturedImageUri: this.props.getSavedData().capturedImageUri,
        },
        () => this.sendImageToServer(),
      );
      console.log('In did Update');
    }
  }

  // static getDerivedStateFromProps(props, state) {
  //   HealthPredection.sendImageToServer(props);
  //   return {...state}
  // }

  proccessServerData = serverResponse => {
    const sample = new HealthPredictor(
      { ...serverResponse },
      {
        age: 99,
        weight: 200,
        pregnancyStatus: false,
        gender: 'Male',
        height: 122,
      },
    );

    const report = sample.getAnalysisReport();

    //console.log(report);

    if (serverResponse && report) {
      this.setState({
        isLoading: false,
        hasError: false,
        predictionReport: report,
        foodName: serverResponse[Constants.foodContentType.FOOD_NAME],
        prediction: report.prediction ?? 'No prediction',
      });
    } else {
      this.setState({
        isLoading: false,
        hasError: true,
        predictionReport: null,
        foodName: 'Not found',
        prediction: 'No prediction',
      });
    }
  };

  sendImageToServer = () => {
    // axios({
    //   method: 'post',
    //   url: `http://${ServerConfig.SERVER_IP}:${ServerConfig.PORT}/analyze`,
    //   data: {
    //     data: this.state.base64ImageForServer,
    //   },
    // })
    //   .then(response => console.log(response['data']))
    //   .catch(err => console.log(err));

    this.setState({
      isLoading: true,
    });

    const mockServerResponse = {
      [Constants.foodContentType.FOOD_NAME]: 'Itlian burger',
      [Constants.foodContentType.CALORIES]: 40,
      [Constants.foodContentType.PROTIEN]: 40,
      [Constants.foodContentType.FATS]: 10,
      [Constants.foodContentType.CARBS]: 10,
    };

    // const sampleServer = new Promise(
    //   (resolve, reject) => resolve(mockServerResponse),
    //   // setTimeout(() => {

    //   // }, this.SERVER_RESPONSE_DELAY),
    // );
    this.proccessServerData(mockServerResponse);
    // sampleServer
    //   .then(response => this.proccessServerData(response))
    //   .catch(err => this.setState({ hasError: true, isLoading: false }));
  };

  goToPrevoiusScreen = () => {
    if (this.props.navigation) this.props.navigation.goBack();
  };

  getErrorScreen() {
    return (
      <View
        style={{
          backgroundColor: 'transparent',
          paddingTop: '20%',
          flex: 1,
          height: '100%',
          width: '100%',
          alignItems: 'center',
          justifyContent: 'center',
        }}>
        <EntypoIcon name="emoji-sad" color="rgba(0,0,0,0.6)" size={50} />

        <Paragraph style={{ paddingHorizontal: 20, paddingVertical: 10 }}>
          Oops, I was unable to recognize that food
        </Paragraph>
      </View>
    );
  }

  getLoadingPlaceholder = () => {
    return (
      <View
        style={{
          backgroundColor: 'transparent',
          paddingTop: '20%',
          flex: 1,
          height: '100%',
          width: '100%',
          alignItems: 'center',
          justifyContent: 'center',
        }}>
        <EntypoIcon name="open-book" color="rgba(0,0,0,0.6)" size={50} />

        <Paragraph style={{ paddingHorizontal: 20, paddingVertical: 10 }}>
          Studying the food
        </Paragraph>
      </View>
    );
  };

  getPredictionStatus = () => {
    const { expectedMacroNutrients, observedMacroNutrients } =
      this.state.predictionReport;

    console.log(this.state.predictionReport);
    return (
      <View style={{ ...styles.container, padding: 10 }}>
        <Title
          style={{
            marginTop: 10,
            marginBottom: 10,
            fontSize: 25,
            paddingHorizontal: 10,
          }}>
          Nutritional value{' '}
        </Title>
        <Paragraph style={{ paddingHorizontal: 10 }}>
          Below values are calculated by comparing the quantity of nutrients in
          the above food and expected daily in take of that nutrient.
        </Paragraph>

        <View>
          {Object.keys(observedMacroNutrients).map((key, index) => {
            return (
              <FoodContentStatusComponent
                key={index + '_macro_nutrient'}
                foodContentType={key}
                foodContentQuantityExpected={expectedMacroNutrients[key]}
                foodContentQuantityObserved={observedMacroNutrients[key]}
              />
            );
          })}
        </View>
      </View>
    );
  };

  getFoodHealthyStatusFabIconAndColor(healthinessLevel) {
    let iconName = 'check';
    let iconBackgroundColor = '#68ca87';

    if (healthinessLevel < 1) {
      iconName = 'close';
      iconBackgroundColor = '#fa5353';
    } else if (healthinessLevel >= 1 && healthinessLevel <= 2) {
      iconName = 'warning';
      iconBackgroundColor = '#EC5800';
    } else if (healthinessLevel >= 2 && healthinessLevel <= 3) {
      iconName = 'like2';
      iconBackgroundColor = '#9acd32';
    } else {
      iconName = 'heart';
      iconBackgroundColor = '#68ca87';
    }

    return { iconName, iconBackgroundColor };
  }

  getFoodHealthyStatusFab = () => {
    const { predictionReport } = this.state;
    if (predictionReport) {
      const { healthinessLevel } = predictionReport;

      console.log("healthy ness weight -> ", healthinessLevel)
      console.log("Prediction report", predictionReport)

      let { iconName, iconBackgroundColor } =
        this.getFoodHealthyStatusFabIconAndColor(healthinessLevel);

      return (
        <AntDesignIcon
          name={iconName}
          color={'#fff'}
          size={25}
          style={{
            ...styles.foodHealthyStatusFab,
            backgroundColor: iconBackgroundColor,
          }}
        />
      );
    }
    return (
      <MatCommunityIcon
        name="brain"
        color={'#fff'}
        size={25}
        style={{
          ...styles.foodHealthyStatusFab,
          backgroundColor: '#008cef',
        }}
      />
    );
  };

  render() {
    const {
      windowPercentHeight,
      capturedImageUri,
      isLoading,
      hasError,
      foodName,
      prediction,
      predictionReport,
    } = this.state;
    return (
      <SafeAreaView>
        {isLoading && !hasError && <LoadingComponent />}
        <ScrollView
          style={{
            ...styles.container,
            backgroundColor: '#fff',
          }}>
          <View style={styles.imageWrapper}>
            <Image
              style={{
                width: '100%',
                height: windowPercentHeight,
              }}
              resizeMode="cover"
              source={
                capturedImageUri
                  ? { uri: capturedImageUri }
                  : require('../../assets/placeholder.png')
              }
            />
            <View style={{ ...styles.imgOverlay, height: windowPercentHeight }}>
              <FAB
                style={styles.backButton}
                small
                icon="arrow-left"
                color="white"
                onPress={() => this.goToPrevoiusScreen()}
              />

              <Card style={styles.foodNameCard}>
                <Text
                  style={{
                    color: 'white',
                    fontSize: 20,
                    fontWeight: 'bold',
                    fontStyle: 'italic',
                  }}>
                  {' '}
                  {capatalizeText(foodName)}{' '}
                </Text>
              </Card>

              <Card style={styles.foodHealthyStatusCard}>
                <Text
                  style={{
                    color: 'white',
                    fontSize: 17,
                    fontWeight: 'bold',
                    fontStyle: 'italic',
                    marginBottom: 8,
                  }}>
                  {capatalizeText(prediction)}{' '}
                </Text>
              </Card>

              {this.getFoodHealthyStatusFab()}
            </View>
          </View>
          {isLoading && !hasError && this.getLoadingPlaceholder()}

          {!isLoading && !hasError && this.getPredictionStatus()}

          {hasError && this.getErrorScreen()}
        </ScrollView>
      </SafeAreaView>
    );
  }
}
export default connectToRedux(HealthPredection);
