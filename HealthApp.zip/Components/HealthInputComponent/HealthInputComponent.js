import React, {PureComponent, Node} from 'react';
import {styles} from './HealthInputComponent.styles';
import {
  SafeAreaView,
  View,
  ScrollView,
  Image,
  ImageBackground,
} from 'react-native';
import {
  Text,
  Card,
  Title,
  Paragraph,
  Button,
  TextInput,
  HelperText,
} from 'react-native-paper';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import connectToRedux from '../../_services/_reduxService';
import {appTitle, DeviceConfig} from '../../Constants';

class HealthInputComponent extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      age: '55',
      errorInAge: !true,
      weight: '65.77',
      errorInWeight: !true,
      height: '154',
      errorInHeight: !true,
      gender: 'Male',
      pregnancyStatus: false,
      screenHeight: DeviceConfig.WINDOW_HEIGHT,
    };
  }

  componentDidMount() {
    const savedInputData = this.props.getSavedData();
    if (savedInputData) {
      this.setState({...savedInputData});
    }
  }

  changeTextInputStateVariables = (stateVariable, updatedValue) => {
    if (stateVariable === 'age') {
      const errorInAge = /^[0-9]+$/.test(updatedValue);
      this.setState({
        [stateVariable]: updatedValue,
        errorInAge: !errorInAge,
      });
    }

    if (stateVariable === 'weight') {
      const errorInWeight = /^\d+(\.\d{1,2})?$/.test(updatedValue);
      this.setState(
        {
          [stateVariable]: updatedValue,
          errorInWeight: !errorInWeight,
        },
        () => console.log(this.state),
      );
    }

    if (stateVariable === 'height') {
      const errorInHeight = /^\d+(\.\d{1,2})?$/.test(updatedValue);
      this.setState(
        {
          [stateVariable]: updatedValue,
          errorInHeight: !errorInHeight,
        },
        () => console.log(this.state),
      );
    }
  };

  hasErrorIn = errorToCheckIn => {
    if (errorToCheckIn === 'weight') {
      return this.state.errorInWeight;
    }

    if (errorToCheckIn === 'height') {
      return this.state.errorInHeight;
    }

    return this.state.errorInAge;
  };

  saveAnswersAndPopCamera = () => {
    const {saveInputData} = this.props;
    if (this.props.navigation) {
      if (saveInputData(this.state))
        this.props.navigation.navigate('CameraComponent');
    }
  };

  setGenderTo = gender => {
    this.setState({gender});
  };

  setPregnancyStatusTo = pregnancyStatus => {
    this.setState({pregnancyStatus});
  };

  render() {
    const {screenHeight, gender, pregnancyStatus} = this.state;

    const minScreenPercentageToCover = 35;

    if (screenHeight)
      return (
        <SafeAreaView style={{flex: 1}}>
          <ImageBackground
            source={require('../../assets/IconGrid.png')}
            resizeMode="cover"
            style={{width: '100%', height: '100%'}}>
            <View style={{flex: 1, backgroundColor: 'transparent'}}>
              <ScrollView
                style={{flex: 1, backgroundColor: 'transparent', evevation: 2}}>
                <View
                  style={{
                    height: (minScreenPercentageToCover * screenHeight) / 100,
                    backgroundColor: 'transparent',
                    paddingHorizontal: 20,
                  }}>
                  <View
                    style={{
                      ...styles.container,
                      backgroundColor: 'transparent',
                      paddingTop: 30,
                      flexDirection: 'row',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                    }}>
                    {/* <Icon name="food-croissant" size={33} color={'#fff'} /> */}
                    <Image
                      source={require('../../assets/logo_no_bg.png')}
                      style={{height: '80%', width: '7%'}}
                    />
                    <Text
                      style={{
                        color: 'white',
                        fontSize: 22,
                        fontStyle: 'italic',
                        marginTop: '5%',
                      }}>
                      {appTitle}
                    </Text>
                  </View>

                  <View
                    style={{
                      ...styles.container,
                      backgroundColor: 'transparent',
                      paddingVertical: '15%',
                    }}>
                    <Title
                      style={{fontSize: 30, color: '#fff', fontWeight: '100'}}>
                      Dashboard
                    </Title>
                    <Paragraph style={{color: '#fff', fontWeight: '100'}}>
                      {' '}
                      Help us to know you better.{' '}
                    </Paragraph>
                  </View>
                </View>

                {/* Age question*/}
                <View
                  style={{
                    ...styles.container,
                    ...styles.bodyCard,
                  }}>
                  <View
                    style={{
                      ...styles.container,
                      marginHorizontal: 20,
                      paddingHorizontal: 0,
                    }}>
                    <View
                      style={{
                        flex: 1,
                        flexDirection: 'column',
                        marginBottom: 25,
                      }}>
                      <Title style={{fontSize: 18}}>Q. What is you age ?</Title>
                      <TextInput
                        mode="outlined"
                        outlineColor="#008cef"
                        placeholder="Enter your age..."
                        keyboardType="numeric"
                        style={{marginTop: 10}}
                        right={<TextInput.Affix text="Years" />}
                        value={this.state.age}
                        onChangeText={text =>
                          this.changeTextInputStateVariables('age', text)
                        }
                      />
                      <HelperText type="error" visible={this.hasErrorIn('age')}>
                        Enter a valid Age !
                      </HelperText>
                    </View>

                    <View
                      style={{
                        flex: 1,
                        flexDirection: 'column',
                        marginBottom: 25,
                        marginTop: 15,
                      }}>
                      <Title style={{fontSize: 18}}>
                        Q. What is you weight ?
                      </Title>
                      <TextInput
                        mode="outlined"
                        outlineColor="#008cef"
                        placeholder="Enter your weight..."
                        keyboardType="numeric"
                        style={{marginTop: 10}}
                        right={<TextInput.Affix text="Kg's" />}
                        value={this.state.weight}
                        onChangeText={text =>
                          this.changeTextInputStateVariables('weight', text)
                        }
                      />
                      <HelperText
                        type="error"
                        visible={this.hasErrorIn('weight')}>
                        Enter a valid Weight !
                      </HelperText>
                    </View>

                    <View
                      style={{
                        flex: 1,
                        flexDirection: 'column',
                        marginBottom: 25,
                        marginTop: 15,
                      }}>
                      <Title style={{fontSize: 18}}>
                        Q. What is you height ?
                      </Title>
                      <TextInput
                        mode="outlined"
                        outlineColor="#008cef"
                        placeholder="Enter your height..."
                        keyboardType="numeric"
                        style={{marginTop: 10}}
                        right={<TextInput.Affix text="cm" />}
                        value={this.state.height}
                        onChangeText={text =>
                          this.changeTextInputStateVariables('height', text)
                        }
                      />
                      <HelperText
                        type="error"
                        visible={this.hasErrorIn('height')}>
                        Enter a valid Height !
                      </HelperText>
                    </View>

                    {/* Gender question*/}
                    <View
                      style={{
                        flex: 1,
                        flexDirection: 'column',
                        marginBottom: 20,
                        marginTop: 15,
                      }}>
                      <Title style={{fontSize: 18}}>
                        Q. What is you gender ?
                      </Title>
                      <View
                        style={{
                          ...styles.container,
                          flexDirection: 'row',
                          justifyContent: 'space-around',
                          marginTop: 20,
                          alignItems: 'center',
                        }}>
                        <Card
                          style={{
                            ...styles.selectionCard,
                            marginRight: 20,
                            borderColor:
                              gender === 'Male' ? '#008cef' : 'transparent',
                            backgroundColor:
                              gender === 'Male'
                                ? 'rgba(0,140,239,0.05)'
                                : 'transparent',
                          }}
                          onPress={() => this.setGenderTo('Male')}>
                          <Card.Content style={{flex: 1, alignItems: 'center'}}>
                            <Title>
                              <Icon
                                name="gender-male"
                                size={35}
                                color="#008cef"
                              />
                            </Title>
                            <Paragraph style={{marginTop: 15}}>Male</Paragraph>
                          </Card.Content>
                        </Card>
                        <Card
                          style={{
                            ...styles.selectionCard,
                            marginLeft: 20,
                            borderColor:
                              gender === 'Female' ? '#fc6c85' : 'transparent',

                            backgroundColor:
                              gender === 'Female'
                                ? 'rgba(252,108,133, 0.05)'
                                : 'transparent',
                          }}
                          onPress={() => this.setGenderTo('Female')}>
                          <Card.Content style={{flex: 1, alignItems: 'center'}}>
                            <Title>
                              <Icon
                                name="gender-female"
                                size={35}
                                color="#fc6c85"
                              />
                            </Title>
                            <Paragraph style={{marginTop: 15}}>
                              Female
                            </Paragraph>
                          </Card.Content>
                        </Card>
                      </View>
                    </View>

                    {/* Concieved question*/}

                    {gender === 'Female' && (
                      <View
                        style={{
                          flex: 1,
                          flexDirection: 'column',
                          marginBottom: 20,
                          marginTop: 50,
                        }}>
                        <Title style={{fontSize: 18}}>
                          Q. What is your pregnancy status ?
                        </Title>
                        <View
                          style={{
                            ...styles.container,
                            flexDirection: 'row',
                            justifyContent: 'space-around',
                            marginTop: 15,
                            alignItems: 'center',
                          }}>
                          <Card
                            style={{
                              ...styles.selectionCard,
                              marginRight: 20,
                              borderColor: pregnancyStatus
                                ? '#68ca87'
                                : 'transparent',
                              backgroundColor: pregnancyStatus
                                ? 'rgba(104,202,135, 0.05)'
                                : 'transparent',
                            }}
                            onPress={() => this.setPregnancyStatusTo(true)}>
                            <Card.Content
                              style={{flex: 1, alignItems: 'center'}}>
                              <Title>
                                <Icon name="plus" size={35} color="#68ca87" />
                              </Title>
                              <Paragraph style={{marginTop: 15}}>
                                Positive
                              </Paragraph>
                            </Card.Content>
                          </Card>
                          <Card
                            style={{
                              ...styles.selectionCard,
                              marginLeft: 20,
                              borderColor: !pregnancyStatus
                                ? '#fa5353'
                                : 'transparent',

                              backgroundColor: !pregnancyStatus
                                ? 'rgba(250,83,83,0.05)'
                                : 'transparent',
                            }}
                            onPress={() => this.setPregnancyStatusTo(false)}>
                            <Card.Content
                              style={{flex: 1, alignItems: 'center'}}>
                              <Title>
                                <Icon name="minus" size={35} color="#fa5353" />
                              </Title>
                              <Paragraph style={{marginTop: 15}}>
                                Negative
                              </Paragraph>
                            </Card.Content>
                          </Card>
                        </View>
                      </View>
                    )}

                    <View style={{paddingBottom: '17%'}}></View>
                  </View>
                </View>
                <View
                  style={{
                    flex: 1,
                    flexDirection: 'column',
                    width: '100%',
                  }}>
                  <Button
                    mode="contained"
                    style={{
                      padding: 5,
                      elevation: 4,
                      backgroundColor:
                        this.hasErrorIn('weight') ||
                        this.hasErrorIn('age') ||
                        this.hasErrorIn('weight') ||
                        this.hasErrorIn('height')
                          ? '#ececec'
                          : '#008cef',
                      width: DeviceConfig.WINDOW_WIDTH,
                      borderRadius: 0,
                    }}
                    disabled={
                      this.hasErrorIn('weight') ||
                      this.hasErrorIn('age') ||
                      this.hasErrorIn('height')
                    }
                    onPress={() => this.saveAnswersAndPopCamera()}>
                    {' '}
                    Open Camera <Icon name="camera" color="white" size={15} />
                  </Button>
                </View>
              </ScrollView>
            </View>
          </ImageBackground>
        </SafeAreaView>
      );

    return null;
  }
}

export default connectToRedux(HealthInputComponent);
