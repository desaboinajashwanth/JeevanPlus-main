import { Dimensions } from 'react-native';

export const foodContentType = Object.freeze({
  FOOD_NAME: "FOOD_NAME",
  PROTIEN: 'PROTIEN',
  FATS: 'FATS',
  CARBS: 'CARBS',
  CALORIES: 'CALORIES',
});

export const appTitle = 'JeevanPlus';

export const genderType = Object.freeze({
  MALE: 'Male',
  FEMALE: 'Female',
});

export const ServerConfig = Object.freeze({
  SERVER_IP: '0.0.0.0',
  PORT: '9001',
});

export const DeviceConfig = Object.freeze({
  WINDOW_HEIGHT: Dimensions.get('window').height,
  WINDOW_WIDTH: Dimensions.get('window').width,
});

// export const dailyProtienData = () => [
//   {age: [1, 3], protien: 13},
//   {age: [4, 8], protien: 19},
//   {age: [9, 13], protien: 34},
//   {age: [14, 18], protien: 46, gender: genderType.FEMALE},
//   {age: [14, 18], protien: 52, gender: genderType.MALE},
//   {age: [19, 200], protien: 46, gender: genderType.FEMALE},
//   {age: [19, 200], protien: 56, gender: genderType.MALE},
//   {pregnancyStatus: true, protien: 71},
// ];

// export const dailyFiberData = () => [
//   {age: [1, 2], fiber: 19},
//   {age: [4, 8], fiber: 25},
//   {age: [9, 13], fiber: 26, gender: genderType.FEMALE},
//   {age: [9, 13], fiber: 31, gender: genderType.MALE},
//   {age: [14, 18], fiber: 26, gender: genderType.FEMALE},
//   {age: [14, 18], fiber: 38, gender: genderType.MALE},
//   {age: [19, 50], fiber: 25, gender: genderType.FEMALE},
//   {age: [19, 50], fiber: 38, gender: genderType.MALE},
//   {age: [50, 200], fiber: 21, gender: genderType.FEMALE},
//   {age: [50, 200], fiber: 30, gender: genderType.MALE},
//   {pregnancyStatus: true, fiber: 28},
// ];

// const baseCarbs = 130;

// export const dailyCarbsData = () => [
//   {age: [1, 8], carbs: baseCarbs},
//   {age: [9, 18], carbs: baseCarbs},
//   {age: [19, 200], carbs: baseCarbs + 40},
//   {pregnancyStatus: true, carbs: baseCarbs + 120},
// ];
