export const capatalizeText = textToCapatalize => {
  if (textToCapatalize)
    if (textToCapatalize.length === 0) return textToCapatalize;
    else if (textToCapatalize.length === 1)
      return textToCapatalize.toUpperCase();
    else
      return `${textToCapatalize.substr(0, 1).toUpperCase()}${textToCapatalize
        .substr(1)
        .toLowerCase()}`;

        
  return textToCapatalize;
};
